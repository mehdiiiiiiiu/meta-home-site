"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  Heart,
  Share2,
  MapPin,
  Bed,
  Bath,
  Maximize,
  Building,
  Phone,
  Mail,
  Calendar,
  Eye,
} from "lucide-react"
import Navbar from "../../components/navbar"
import Link from "next/link"

// Mock property data - in real app, this would come from API
const propertyData = {
  id: 1,
  title: "Luxury Penthouse Downtown",
  price: 2500000,
  location: "Manhattan, NY",
  address: "123 Park Avenue, New York, NY 10016",
  bedrooms: 3,
  bathrooms: 2,
  sqft: 2400,
  yearBuilt: 2020,
  propertyType: "Penthouse",
  description:
    "Experience luxury living at its finest in this stunning penthouse featuring floor-to-ceiling windows, premium finishes, and breathtaking city views. This exceptional property offers an open-concept design with high-end appliances and custom millwork throughout.",
  features: ["Balcony", "Parking", "Elevator", "Pool", "Gym", "Concierge", "Rooftop Terrace"],
  images: [
    "/placeholder.svg?height=600&width=800",
    "/placeholder.svg?height=600&width=800",
    "/placeholder.svg?height=600&width=800",
    "/placeholder.svg?height=600&width=800",
    "/placeholder.svg?height=600&width=800",
  ],
  virtualTour: "https://example.com/tour1",
  agent: {
    name: "Sarah Johnson",
    phone: "+1 (555) 123-4567",
    email: "sarah@estatehub.com",
    image: "/placeholder.svg?height=100&width=100",
    rating: 4.9,
    properties: 127,
  },
}

export default function PropertyDetailPage({ params }: { params: { id: string } }) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isLiked, setIsLiked] = useState(false)
  const [showVirtualTour, setShowVirtualTour] = useState(false)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="mb-6">
          <Button variant="ghost" asChild className="text-gray-600 hover:text-gray-900">
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Properties
            </Link>
          </Button>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image Gallery */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
              <Card className="overflow-hidden shadow-xl border-0">
                <div className="relative h-96">
                  <Image
                    src={propertyData.images[currentImageIndex] || "/placeholder.svg"}
                    alt={propertyData.title}
                    fill
                    className="object-cover"
                  />

                  {/* Action Buttons */}
                  <div className="absolute top-4 right-4 flex space-x-2">
                    <Button
                      size="icon"
                      variant="secondary"
                      className="bg-white/90 hover:bg-white"
                      onClick={() => setIsLiked(!isLiked)}
                    >
                      <Heart className={`w-4 h-4 ${isLiked ? "fill-red-500 text-red-500" : "text-gray-600"}`} />
                    </Button>
                    <Button size="icon" variant="secondary" className="bg-white/90 hover:bg-white">
                      <Share2 className="w-4 h-4 text-gray-600" />
                    </Button>
                  </div>

                  {/* Virtual Tour Button */}
                  <div className="absolute bottom-4 left-4">
                    <Button
                      onClick={() => setShowVirtualTour(true)}
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      360° Virtual Tour
                    </Button>
                  </div>
                </div>
              </Card>

              {/* Thumbnail Gallery */}
              <div className="flex space-x-2 overflow-x-auto">
                {propertyData.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`relative flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                      currentImageIndex === index ? "border-blue-500" : "border-gray-200"
                    }`}
                  >
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`Property image ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Property Details */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <Card className="shadow-lg border-0">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-3xl font-bold text-gray-900 mb-2">{propertyData.title}</CardTitle>
                      <div className="flex items-center text-gray-600 mb-4">
                        <MapPin className="w-5 h-5 mr-2" />
                        <span>{propertyData.address}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-green-600 mb-1">{formatPrice(propertyData.price)}</div>
                      <Badge variant="outline">{propertyData.propertyType}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="overview" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="overview">Overview</TabsTrigger>
                      <TabsTrigger value="features">Features</TabsTrigger>
                      <TabsTrigger value="location">Location</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                      {/* Property Stats */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <Bed className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                          <div className="font-semibold">{propertyData.bedrooms}</div>
                          <div className="text-sm text-gray-600">Bedrooms</div>
                        </div>
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <Bath className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                          <div className="font-semibold">{propertyData.bathrooms}</div>
                          <div className="text-sm text-gray-600">Bathrooms</div>
                        </div>
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <Maximize className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                          <div className="font-semibold">{propertyData.sqft.toLocaleString()}</div>
                          <div className="text-sm text-gray-600">Sq Ft</div>
                        </div>
                        <div className="text-center p-4 bg-gray-50 rounded-lg">
                          <Building className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                          <div className="font-semibold">{propertyData.yearBuilt}</div>
                          <div className="text-sm text-gray-600">Year Built</div>
                        </div>
                      </div>

                      <Separator />

                      {/* Description */}
                      <div>
                        <h3 className="text-xl font-semibold mb-3">Description</h3>
                        <p className="text-gray-700 leading-relaxed">{propertyData.description}</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="features" className="space-y-4">
                      <h3 className="text-xl font-semibold">Property Features</h3>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {propertyData.features.map((feature, index) => (
                          <div key={index} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                            <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                            <span className="text-sm font-medium">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </TabsContent>

                    <TabsContent value="location" className="space-y-4">
                      <h3 className="text-xl font-semibold">Location & Map</h3>
                      <div className="h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                        <div className="text-center text-gray-500">
                          <MapPin className="w-12 h-12 mx-auto mb-2" />
                          <p>Interactive Map Would Load Here</p>
                          <p className="text-sm">Integration with Google Maps or Mapbox</p>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Agent Contact */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
              <Card className="shadow-lg border-0">
                <CardHeader>
                  <CardTitle>Contact Agent</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="relative w-12 h-12">
                      <Image
                        src={propertyData.agent.image || "/placeholder.svg"}
                        alt={propertyData.agent.name}
                        fill
                        className="rounded-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="font-semibold">{propertyData.agent.name}</div>
                      <div className="text-sm text-gray-600">
                        ⭐ {propertyData.agent.rating} • {propertyData.agent.properties} properties
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                      <Phone className="w-4 h-4 mr-2" />
                      Call Agent
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Mail className="w-4 h-4 mr-2" />
                      Send Message
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Calendar className="w-4 h-4 mr-2" />
                      Schedule Tour
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Mortgage Calculator */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
              <Card className="shadow-lg border-0">
                <CardHeader>
                  <CardTitle>Mortgage Calculator</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Loan Amount</label>
                      <div className="text-2xl font-bold text-green-600">{formatPrice(propertyData.price * 0.8)}</div>
                      <div className="text-sm text-gray-600">80% of property value</div>
                    </div>
                    <Separator />
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-gray-600">Monthly Payment</div>
                        <div className="font-semibold">$12,450</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Interest Rate</div>
                        <div className="font-semibold">6.5%</div>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full">
                      Get Pre-Approved
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Virtual Tour Modal */}
      {showVirtualTour && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-4xl h-3/4 relative">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 z-10"
              onClick={() => setShowVirtualTour(false)}
            >
              ×
            </Button>
            <div className="w-full h-full rounded-lg overflow-hidden">
              <iframe src={propertyData.virtualTour} className="w-full h-full" title="Virtual Tour" allowFullScreen />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

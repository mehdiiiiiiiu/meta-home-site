import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "املاک ایران - پلتفرم جامع خرید و فروش املاک",
  description: "بهترین پلتفرم برای خرید، فروش و اجاره املاک در سراسر ایران. با تورهای مجازی ۳۶۰ درجه و مشاوران متخصص.",
  keywords: "املاک، خرید خانه، فروش ملک، اجاره آپارتمان، ویلا، تهران، اصفهان، شیراز",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fa" dir="rtl">
      <body className="persian-numbers">{children}</body>
    </html>
  )
}

"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Home, Users, Car, Building } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import InteractiveIranMap from "./components/interactive-iran-map"
import PropertyCard from "./components/property-card"
import Navbar from "./components/navbar"
import Hero from "./components/hero"

const featuredProperties = [
  {
    id: 1,
    title: "آپارتمان لوکس در شمال تهران",
    price: 25000000000,
    location: "تهران، نیاوران",
    bedrooms: 3,
    bathrooms: 2,
    sqft: 150,
    image: "/placeholder.svg?height=300&width=400",
    features: ["بالکن", "پارکینگ", "آسانسور", "استخر"],
    virtualTour: "https://example.com/tour1",
  },
  {
    id: 2,
    title: "ویلا مدرن در شیراز",
    price: 18000000000,
    location: "شیراز، دروازه قرآن",
    bedrooms: 4,
    bathrooms: 3,
    sqft: 250,
    image: "/placeholder.svg?height=300&width=400",
    features: ["باغ", "پارکینگ", "شومینه"],
    virtualTour: "https://example.com/tour2",
  },
  {
    id: 3,
    title: "آپارتمان نوساز در اصفهان",
    price: 12000000000,
    location: "اصفهان، چهارباغ",
    bedrooms: 2,
    bathrooms: 1,
    sqft: 85,
    image: "/placeholder.svg?height=300&width=400",
    features: ["بالکن", "دسترسی به باشگاه"],
    virtualTour: "https://example.com/tour3",
  },
]

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [propertyType, setPropertyType] = useState("")
  const [priceRange, setPriceRange] = useState("")
  const [selectedProvince, setSelectedProvince] = useState("")

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      <Navbar />

      {/* Hero Section */}
      <Hero />

      {/* Advanced Search Bar */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="container mx-auto px-4 -mt-16 relative z-10"
      >
        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <div className="lg:col-span-2">
                <div className="relative">
                  <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="جستجو بر اساس موقعیت، نام ملک..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10 h-12 border-gray-200 focus:border-blue-500 text-right"
                  />
                </div>
              </div>

              <Select value={propertyType} onValueChange={setPropertyType}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="نوع ملک" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="apartment">آپارتمان</SelectItem>
                  <SelectItem value="house">خانه</SelectItem>
                  <SelectItem value="villa">ویلا</SelectItem>
                  <SelectItem value="office">اداری</SelectItem>
                </SelectContent>
              </Select>

              <Select value={priceRange} onValueChange={setPriceRange}>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="محدوده قیمت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-5b">تا ۵ میلیارد</SelectItem>
                  <SelectItem value="5b-10b">۵ تا ۱۰ میلیارد</SelectItem>
                  <SelectItem value="10b-20b">۱۰ تا ۲۰ میلیارد</SelectItem>
                  <SelectItem value="20b+">بالای ۲۰ میلیارد</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="تعداد اتاق" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">۱+ اتاق</SelectItem>
                  <SelectItem value="2">۲+ اتاق</SelectItem>
                  <SelectItem value="3">۳+ اتاق</SelectItem>
                  <SelectItem value="4">۴+ اتاق</SelectItem>
                </SelectContent>
              </Select>

              <Button className="h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Search className="w-4 h-4 ml-2" />
                جستجو
              </Button>
            </div>

            {/* Advanced Filters */}
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="mt-6 pt-6 border-t border-gray-200"
            >
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="cursor-pointer hover:bg-blue-50">
                  <Car className="w-3 h-3 ml-1" />
                  پارکینگ
                </Badge>
                <Badge variant="outline" className="cursor-pointer hover:bg-blue-50">
                  <Building className="w-3 h-3 ml-1" />
                  آسانسور
                </Badge>
                <Badge variant="outline" className="cursor-pointer hover:bg-blue-50">
                  <Home className="w-3 h-3 ml-1" />
                  بالکن
                </Badge>
                <Badge variant="outline" className="cursor-pointer hover:bg-blue-50">
                  <Users className="w-3 h-3 ml-1" />
                  استخر
                </Badge>
              </div>
            </motion.div>
          </CardContent>
        </Card>
      </motion.section>

      {/* Interactive Iran Map Section */}
      <section className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">کاوش املاک بر اساس استان</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            روی استان‌های مختلف کلیک کنید تا املاک فوق‌العاده در منطقه مورد نظرتان را کشف کنید
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <InteractiveIranMap onProvinceSelect={setSelectedProvince} />
        </motion.div>
      </section>

      {/* Featured Properties */}
      <section className="container mx-auto px-4 py-16 bg-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">املاک ویژه</h2>
          <p className="text-xl text-gray-600">مجموعه‌ای منتخب از بهترین املاک پریمیوم</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProperties.map((property, index) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <PropertyCard property={property} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-4xl font-bold mb-2">۱۰,۰۰۰+</div>
              <div className="text-blue-100">ملک ثبت شده</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <div className="text-4xl font-bold mb-2">۵,۰۰۰+</div>
              <div className="text-blue-100">مشتری راضی</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="text-4xl font-bold mb-2">۵۰۰+</div>
              <div className="text-blue-100">مشاور متخصص</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="text-4xl font-bold mb-2">۳۱</div>
              <div className="text-blue-100">استان تحت پوشش</div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}

import { type NextRequest, NextResponse } from "next/server"

// Mock database for Iranian properties
const properties = [
  {
    id: 1,
    title: "آپارتمان لوکس در شمال تهران",
    price: 25000000000,
    location: "تهران، نیاوران",
    address: "تهران، نیاوران، خیابان شهید بهشتی",
    bedrooms: 3,
    bathrooms: 2,
    sqft: 150,
    yearBuilt: 1400,
    propertyType: "آپارتمان",
    description:
      "آپارتمان لوکس با امکانات کامل در بهترین منطقه شمال تهران. دارای نمای شیشه‌ای، تراس بزرگ و چشم‌انداز فوق‌العاده به کوه‌های البرز.",
    features: ["بالکن", "پارکینگ", "آسانسور", "استخر", "باشگاه", "نگهبانی"],
    images: [
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
      "/placeholder.svg?height=600&width=800",
    ],
    virtualTour: "https://example.com/tour1",
    agent: {
      id: 1,
      name: "سارا احمدی",
      phone: "۰۹۱۲۱۲۳۴۵۶۷",
      email: "sara@estateiran.com",
    },
    status: "active",
    createdAt: "2024-01-15T00:00:00Z",
    updatedAt: "2024-01-15T00:00:00Z",
  },
  {
    id: 2,
    title: "ویلا مدرن در شیراز",
    price: 18000000000,
    location: "شیراز، دروازه قرآن",
    address: "شیراز، دروازه قرآن، کوچه گلستان",
    bedrooms: 4,
    bathrooms: 3,
    sqft: 250,
    yearBuilt: 1398,
    propertyType: "ویلا",
    description: "ویلای زیبا با باغ بزرگ و معماری مدرن در بهترین منطقه شیراز. مناسب برای خانواده‌های بزرگ.",
    features: ["باغ", "پارکینگ", "شومینه", "آشپزخانه مدرن"],
    images: ["/placeholder.svg?height=600&width=800", "/placeholder.svg?height=600&width=800"],
    virtualTour: "https://example.com/tour2",
    agent: {
      id: 2,
      name: "محمد رضایی",
      phone: "۰۹۱۷۹۸۷۶۵۴۳",
      email: "mohammad@estateiran.com",
    },
    status: "active",
    createdAt: "2024-01-10T00:00:00Z",
    updatedAt: "2024-01-10T00:00:00Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const propertyType = searchParams.get("propertyType") || ""
    const minPrice = Number.parseInt(searchParams.get("minPrice") || "0")
    const maxPrice = Number.parseInt(searchParams.get("maxPrice") || "999999999999")

    // Filter properties based on query parameters
    const filteredProperties = properties.filter((property) => {
      const matchesSearch = property.title.includes(search) || property.location.includes(search)
      const matchesType = !propertyType || property.propertyType === propertyType
      const matchesPrice = property.price >= minPrice && property.price <= maxPrice

      return matchesSearch && matchesType && matchesPrice
    })

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedProperties = filteredProperties.slice(startIndex, endIndex)

    return NextResponse.json({
      properties: paginatedProperties,
      pagination: {
        page,
        limit,
        total: filteredProperties.length,
        pages: Math.ceil(filteredProperties.length / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching properties:", error)
    return NextResponse.json({ error: "خطا در دریافت املاک" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    const requiredFields = ["title", "price", "location", "bedrooms", "bathrooms", "sqft", "propertyType"]
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ error: `فیلد الزامی: ${field}` }, { status: 400 })
      }
    }

    // Create new property
    const newProperty = {
      id: properties.length + 1,
      ...body,
      status: "pending", // New listings start as pending
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    properties.push(newProperty)

    return NextResponse.json(newProperty, { status: 201 })
  } catch (error) {
    console.error("Error creating property:", error)
    return NextResponse.json({ error: "خطا در ایجاد ملک" }, { status: 500 })
  }
}

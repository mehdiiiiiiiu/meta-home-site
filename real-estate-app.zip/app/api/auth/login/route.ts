import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import bcrypt from "bcryptjs"

// Mock user database - in production, this would be MongoDB/PostgreSQL
const users = [
  {
    id: 1,
    email: "user@example.com",
    password: "$2a$10$rOzJqZxnTkDg1.5F5F5F5eF5F5F5F5F5F5F5F5F5F5F5F5F5F5F5F5", // 'password123'
    firstName: "John",
    lastName: "Doe",
    role: "user",
    phone: "+1 (555) 123-4567",
    createdAt: "2024-01-01T00:00:00Z",
  },
  {
    id: 2,
    email: "agent@example.com",
    password: "$2a$10$rOzJqZxnTkDg1.5F5F5F5eF5F5F5F5F5F5F5F5F5F5F5F5F5F5F5F5", // 'password123'
    firstName: "Sarah",
    lastName: "Johnson",
    role: "agent",
    phone: "+1 (555) 987-6543",
    createdAt: "2024-01-01T00:00:00Z",
  },
  {
    id: 3,
    email: "admin@example.com",
    password: "$2a$10$rOzJqZxnTkDg1.5F5F5F5eF5F5F5F5F5F5F5F5F5F5F5F5F5F5F5F5", // 'password123'
    firstName: "Admin",
    lastName: "User",
    role: "admin",
    phone: "+1 (555) 555-5555",
    createdAt: "2024-01-01T00:00:00Z",
  },
]

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Validate input
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    // Find user
    const user = users.find((u) => u.email === email)
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password)
    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      process.env.JWT_SECRET || "your-secret-key",
      { expiresIn: "7d" },
    )

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      user: userWithoutPassword,
      token,
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

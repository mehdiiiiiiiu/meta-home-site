"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin } from "lucide-react"

interface Region {
  id: string
  name: string
  properties: number
  avgPrice: string
  coordinates: { x: number; y: number }
}

const regions: Region[] = [
  { id: "manhattan", name: "Manhattan", properties: 1250, avgPrice: "$2.5M", coordinates: { x: 45, y: 30 } },
  { id: "brooklyn", name: "Brooklyn", properties: 890, avgPrice: "$1.2M", coordinates: { x: 55, y: 45 } },
  { id: "queens", name: "Queens", properties: 670, avgPrice: "$850K", coordinates: { x: 65, y: 35 } },
  { id: "bronx", name: "Bronx", properties: 420, avgPrice: "$650K", coordinates: { x: 50, y: 20 } },
  { id: "staten", name: "Staten Island", properties: 280, avgPrice: "$750K", coordinates: { x: 35, y: 60 } },
]

interface InteractiveMapProps {
  onRegionSelect: (region: string) => void
}

export default function InteractiveMap({ onRegionSelect }: InteractiveMapProps) {
  const [selectedRegion, setSelectedRegion] = useState<string | null>(null)
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null)

  const handleRegionClick = (regionId: string) => {
    setSelectedRegion(regionId)
    onRegionSelect(regionId)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Map Visualization */}
      <div className="lg:col-span-2">
        <Card className="overflow-hidden shadow-2xl border-0">
          <CardContent className="p-0">
            <div className="relative h-96 bg-gradient-to-br from-blue-50 to-purple-50">
              {/* Simplified NYC Map Background */}
              <svg
                viewBox="0 0 100 100"
                className="w-full h-full"
                style={{ filter: "drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))" }}
              >
                {/* Water areas */}
                <rect x="0" y="0" width="100" height="100" fill="#e0f2fe" />

                {/* Land masses */}
                <path d="M20,15 L80,15 L80,85 L20,85 Z" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="0.5" />

                {/* Region boundaries */}
                <path
                  d="M20,15 L50,15 L50,40 L20,40 Z"
                  fill={
                    selectedRegion === "manhattan" ? "#3b82f6" : hoveredRegion === "manhattan" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                />
                <path
                  d="M50,40 L80,40 L80,70 L50,70 Z"
                  fill={
                    selectedRegion === "brooklyn" ? "#3b82f6" : hoveredRegion === "brooklyn" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                />
                <path
                  d="M50,15 L80,15 L80,40 L50,40 Z"
                  fill={selectedRegion === "queens" ? "#3b82f6" : hoveredRegion === "queens" ? "#60a5fa" : "#e2e8f0"}
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                />
                <path
                  d="M20,15 L50,15 L50,25 L20,25 Z"
                  fill={selectedRegion === "bronx" ? "#3b82f6" : hoveredRegion === "bronx" ? "#60a5fa" : "#e2e8f0"}
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                />
                <path
                  d="M15,50 L40,50 L40,80 L15,80 Z"
                  fill={selectedRegion === "staten" ? "#3b82f6" : hoveredRegion === "staten" ? "#60a5fa" : "#e2e8f0"}
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                />
              </svg>

              {/* Interactive Markers */}
              {regions.map((region) => (
                <motion.div
                  key={region.id}
                  className="absolute cursor-pointer"
                  style={{
                    left: `${region.coordinates.x}%`,
                    top: `${region.coordinates.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleRegionClick(region.id)}
                  onMouseEnter={() => setHoveredRegion(region.id)}
                  onMouseLeave={() => setHoveredRegion(null)}
                >
                  <div
                    className={`w-4 h-4 rounded-full border-2 border-white shadow-lg transition-all duration-300 ${
                      selectedRegion === region.id
                        ? "bg-blue-600 scale-125"
                        : hoveredRegion === region.id
                          ? "bg-blue-400"
                          : "bg-blue-500"
                    }`}
                  >
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                      <Badge
                        variant="secondary"
                        className={`text-xs transition-opacity duration-300 ${
                          hoveredRegion === region.id || selectedRegion === region.id ? "opacity-100" : "opacity-0"
                        }`}
                      >
                        {region.name}
                      </Badge>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Region Information */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">Select a Region</h3>
        {regions.map((region) => (
          <motion.div key={region.id} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Card
              className={`cursor-pointer transition-all duration-300 ${
                selectedRegion === region.id ? "ring-2 ring-blue-500 shadow-lg" : "hover:shadow-md"
              }`}
              onClick={() => handleRegionClick(region.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <h4 className="font-semibold text-gray-900">{region.name}</h4>
                  </div>
                  <Badge variant="outline">{region.properties} properties</Badge>
                </div>
                <p className="text-sm text-gray-600">
                  Average Price: <span className="font-semibold text-green-600">{region.avgPrice}</span>
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

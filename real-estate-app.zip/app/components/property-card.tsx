"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, MapPin, Bed, Bath, Maximize, Eye, Share2 } from "lucide-react"

interface Property {
  id: number
  title: string
  price: number
  location: string
  bedrooms: number
  bathrooms: number
  sqft: number
  image: string
  features: string[]
  virtualTour?: string
}

interface PropertyCardProps {
  property: Property
}

export default function PropertyCard({ property }: PropertyCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("fa-IR").format(price) + " تومان"
  }

  return (
    <motion.div whileHover={{ y: -8 }} transition={{ duration: 0.3 }} dir="rtl">
      <Card className="overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border-0 bg-white">
        <div className="relative">
          {/* Property Image */}
          <div className="relative h-64 overflow-hidden">
            <Image
              src={property.image || "/placeholder.svg"}
              alt={property.title}
              fill
              className={`object-cover transition-all duration-500 ${
                imageLoaded ? "scale-100 opacity-100" : "scale-110 opacity-0"
              }`}
              onLoad={() => setImageLoaded(true)}
            />

            {/* Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />

            {/* Action Buttons */}
            <div className="absolute top-4 left-4 flex space-x-2 space-x-reverse">
              <Button
                size="icon"
                variant="secondary"
                className="w-8 h-8 bg-white/90 hover:bg-white"
                onClick={(e) => {
                  e.preventDefault()
                  setIsLiked(!isLiked)
                }}
              >
                <Heart className={`w-4 h-4 ${isLiked ? "fill-red-500 text-red-500" : "text-gray-600"}`} />
              </Button>
              <Button size="icon" variant="secondary" className="w-8 h-8 bg-white/90 hover:bg-white">
                <Share2 className="w-4 h-4 text-gray-600" />
              </Button>
            </div>

            {/* Price Badge */}
            <div className="absolute top-4 right-4">
              <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold px-3 py-1">
                {formatPrice(property.price)}
              </Badge>
            </div>

            {/* Virtual Tour Badge */}
            {property.virtualTour && (
              <div className="absolute bottom-4 right-4">
                <Badge variant="secondary" className="bg-white/90 text-gray-900">
                  <Eye className="w-3 h-3 ml-1" />
                  تور ۳۶۰°
                </Badge>
              </div>
            )}
          </div>

          <CardContent className="p-6">
            {/* Property Title */}
            <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2">{property.title}</h3>

            {/* Location */}
            <div className="flex items-center text-gray-600 mb-4">
              <MapPin className="w-4 h-4 ml-1" />
              <span className="text-sm">{property.location}</span>
            </div>

            {/* Property Details */}
            <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
              <div className="flex items-center space-x-4 space-x-reverse">
                <div className="flex items-center">
                  <Bed className="w-4 h-4 ml-1" />
                  <span>{property.bedrooms} اتاق</span>
                </div>
                <div className="flex items-center">
                  <Bath className="w-4 h-4 ml-1" />
                  <span>{property.bathrooms} حمام</span>
                </div>
                <div className="flex items-center">
                  <Maximize className="w-4 h-4 ml-1" />
                  <span>{property.sqft} متر</span>
                </div>
              </div>
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-2 mb-4">
              {property.features.slice(0, 3).map((feature, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {feature}
                </Badge>
              ))}
              {property.features.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{property.features.length - 3} مورد دیگر
                </Badge>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-2 space-x-reverse">
              <Button
                asChild
                className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Link href={`/property/${property.id}`}>مشاهده جزئیات</Link>
              </Button>
              {property.virtualTour && (
                <Button variant="outline" size="icon">
                  <Eye className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </div>
      </Card>
    </motion.div>
  )
}

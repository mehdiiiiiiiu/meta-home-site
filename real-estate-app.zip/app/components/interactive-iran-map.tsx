"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin } from "lucide-react"

interface Province {
  id: string
  name: string
  properties: number
  avgPrice: string
  coordinates: { x: number; y: number }
}

const iranProvinces: Province[] = [
  { id: "tehran", name: "تهران", properties: 3250, avgPrice: "۲۵ میلیارد", coordinates: { x: 51, y: 35 } },
  { id: "isfahan", name: "اصفهان", properties: 1890, avgPrice: "۱۵ میلیارد", coordinates: { x: 51.5, y: 45 } },
  { id: "shiraz", name: "شیراز", properties: 1670, avgPrice: "۱۸ میلیارد", coordinates: { x: 45, y: 65 } },
  { id: "mashhad", name: "مشهد", properties: 1420, avgPrice: "۱۲ میلیارد", coordinates: { x: 75, y: 25 } },
  { id: "tabriz", name: "تبریز", properties: 980, avgPrice: "۱۰ میلیارد", coordinates: { x: 35, y: 20 } },
  { id: "ahvaz", name: "اهواز", properties: 750, avgPrice: "۸ میلیارد", coordinates: { x: 40, y: 70 } },
  { id: "qom", name: "قم", properties: 650, avgPrice: "۱۴ میلیارد", coordinates: { x: 48, y: 42 } },
  { id: "karaj", name: "کرج", properties: 1200, avgPrice: "۲۰ میلیارد", coordinates: { x: 47, y: 32 } },
]

interface InteractiveIranMapProps {
  onProvinceSelect: (province: string) => void
}

export default function InteractiveIranMap({ onProvinceSelect }: InteractiveIranMapProps) {
  const [selectedProvince, setSelectedProvince] = useState<string | null>(null)
  const [hoveredProvince, setHoveredProvince] = useState<string | null>(null)

  const handleProvinceClick = (provinceId: string) => {
    setSelectedProvince(provinceId)
    onProvinceSelect(provinceId)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Iran Map Visualization */}
      <div className="lg:col-span-2">
        <Card className="overflow-hidden shadow-2xl border-0">
          <CardContent className="p-0">
            <div className="relative h-96 bg-gradient-to-br from-blue-50 to-purple-50">
              {/* Simplified Iran Map */}
              <svg
                viewBox="0 0 100 100"
                className="w-full h-full"
                style={{ filter: "drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))" }}
              >
                {/* Iran country outline */}
                <path
                  d="M15,25 Q20,15 35,18 Q50,12 65,15 Q80,18 85,25 Q88,35 85,45 Q82,55 78,65 Q70,75 60,80 Q45,85 30,82 Q20,78 15,70 Q12,60 10,50 Q8,40 12,30 Z"
                  fill="#f1f5f9"
                  stroke="#cbd5e1"
                  strokeWidth="0.5"
                />

                {/* Tehran Province */}
                <path
                  d="M45,30 Q55,28 58,35 Q55,42 45,40 Q40,35 45,30 Z"
                  fill={
                    selectedProvince === "tehran" ? "#3b82f6" : hoveredProvince === "tehran" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                  onClick={() => handleProvinceClick("tehran")}
                  onMouseEnter={() => setHoveredProvince("tehran")}
                  onMouseLeave={() => setHoveredProvince(null)}
                />

                {/* Isfahan Province */}
                <path
                  d="M45,40 Q55,38 58,48 Q52,55 42,52 Q38,45 45,40 Z"
                  fill={
                    selectedProvince === "isfahan" ? "#3b82f6" : hoveredProvince === "isfahan" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                  onClick={() => handleProvinceClick("isfahan")}
                  onMouseEnter={() => setHoveredProvince("isfahan")}
                  onMouseLeave={() => setHoveredProvince(null)}
                />

                {/* Fars Province (Shiraz) */}
                <path
                  d="M35,60 Q50,58 55,68 Q48,75 35,72 Q28,65 35,60 Z"
                  fill={
                    selectedProvince === "shiraz" ? "#3b82f6" : hoveredProvince === "shiraz" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                  onClick={() => handleProvinceClick("shiraz")}
                  onMouseEnter={() => setHoveredProvince("shiraz")}
                  onMouseLeave={() => setHoveredProvince(null)}
                />

                {/* Khorasan Province (Mashhad) */}
                <path
                  d="M65,20 Q80,18 82,28 Q78,35 65,32 Q60,25 65,20 Z"
                  fill={
                    selectedProvince === "mashhad" ? "#3b82f6" : hoveredProvince === "mashhad" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                  onClick={() => handleProvinceClick("mashhad")}
                  onMouseEnter={() => setHoveredProvince("mashhad")}
                  onMouseLeave={() => setHoveredProvince(null)}
                />

                {/* East Azerbaijan Province (Tabriz) */}
                <path
                  d="M25,15 Q40,12 42,22 Q38,28 25,25 Q20,18 25,15 Z"
                  fill={
                    selectedProvince === "tabriz" ? "#3b82f6" : hoveredProvince === "tabriz" ? "#60a5fa" : "#e2e8f0"
                  }
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                  onClick={() => handleProvinceClick("tabriz")}
                  onMouseEnter={() => setHoveredProvince("tabriz")}
                  onMouseLeave={() => setHoveredProvince(null)}
                />

                {/* Khuzestan Province (Ahvaz) */}
                <path
                  d="M25,65 Q40,62 42,72 Q35,78 25,75 Q18,68 25,65 Z"
                  fill={selectedProvince === "ahvaz" ? "#3b82f6" : hoveredProvince === "ahvaz" ? "#60a5fa" : "#e2e8f0"}
                  stroke="#94a3b8"
                  strokeWidth="0.5"
                  className="cursor-pointer transition-all duration-300"
                  onClick={() => handleProvinceClick("ahvaz")}
                  onMouseEnter={() => setHoveredProvince("ahvaz")}
                  onMouseLeave={() => setHoveredProvince(null)}
                />
              </svg>

              {/* Interactive Markers */}
              {iranProvinces.map((province) => (
                <motion.div
                  key={province.id}
                  className="absolute cursor-pointer"
                  style={{
                    left: `${province.coordinates.x}%`,
                    top: `${province.coordinates.y}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => handleProvinceClick(province.id)}
                  onMouseEnter={() => setHoveredProvince(province.id)}
                  onMouseLeave={() => setHoveredProvince(null)}
                >
                  <div
                    className={`w-4 h-4 rounded-full border-2 border-white shadow-lg transition-all duration-300 ${
                      selectedProvince === province.id
                        ? "bg-blue-600 scale-125"
                        : hoveredProvince === province.id
                          ? "bg-blue-400"
                          : "bg-blue-500"
                    }`}
                  >
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                      <Badge
                        variant="secondary"
                        className={`text-xs transition-opacity duration-300 ${
                          hoveredProvince === province.id || selectedProvince === province.id
                            ? "opacity-100"
                            : "opacity-0"
                        }`}
                      >
                        {province.name}
                      </Badge>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Province Information */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-gray-900 mb-6">انتخاب استان</h3>
        {iranProvinces.map((province) => (
          <motion.div key={province.id} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Card
              className={`cursor-pointer transition-all duration-300 ${
                selectedProvince === province.id ? "ring-2 ring-blue-500 shadow-lg" : "hover:shadow-md"
              }`}
              onClick={() => handleProvinceClick(province.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <h4 className="font-semibold text-gray-900">{province.name}</h4>
                  </div>
                  <Badge variant="outline">{province.properties.toLocaleString("fa-IR")} ملک</Badge>
                </div>
                <p className="text-sm text-gray-600">
                  قیمت متوسط: <span className="font-semibold text-green-600">{province.avgPrice} تومان</span>
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
